#ifndef DS_H
#define DS_H

#include <STC15F2K60S2.h>
#include <intrins.h>






void DS1();
void DS2(unsigned int da);


#endif