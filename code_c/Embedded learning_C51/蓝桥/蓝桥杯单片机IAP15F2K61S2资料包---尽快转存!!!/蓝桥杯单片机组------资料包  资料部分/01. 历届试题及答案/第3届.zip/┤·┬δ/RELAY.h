#ifndef RELAY_H
#define REALY_H

#include <STC15F2K60S2.h>

void OppenRelay();
void CloseRelay();

#endif