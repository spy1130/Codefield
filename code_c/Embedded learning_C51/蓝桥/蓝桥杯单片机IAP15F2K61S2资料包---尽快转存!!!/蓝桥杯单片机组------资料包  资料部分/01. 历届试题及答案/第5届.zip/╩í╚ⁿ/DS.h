#ifndef DS_H
#define DS_H

#include <STC15F2K60S2.h>
#include <intrins.h>

#define Y6 0xC0
#define Y7 0xE0

void DS1(unsigned char yi,unsigned char er,unsigned char san);
void DS2();
void DS3(unsigned char yi,unsigned char er,unsigned char san);

#endif