#ifndef DS1302_H
#define DS1302_H

extern unsigned char DisplayTime[];

void Init_DS1302();
void Read_DS1302();

#endif
