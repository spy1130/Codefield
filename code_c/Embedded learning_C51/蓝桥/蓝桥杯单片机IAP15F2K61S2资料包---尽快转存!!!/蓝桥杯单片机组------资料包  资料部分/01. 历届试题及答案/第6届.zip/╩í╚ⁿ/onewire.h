#ifndef ONEWIRE_H
#define ONEWIRE_H


unsigned char rd_temperature(void); 

#endif
