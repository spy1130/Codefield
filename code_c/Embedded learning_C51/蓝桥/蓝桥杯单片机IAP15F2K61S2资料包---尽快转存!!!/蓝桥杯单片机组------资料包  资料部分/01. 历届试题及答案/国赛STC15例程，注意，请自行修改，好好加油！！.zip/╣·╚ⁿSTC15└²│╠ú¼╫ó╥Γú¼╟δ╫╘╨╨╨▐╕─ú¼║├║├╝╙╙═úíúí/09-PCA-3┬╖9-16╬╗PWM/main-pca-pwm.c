
#include	"config.h"
#include	"PCA.h"
#include	"delay.h"

/*************	����˵��	**************

���3·9~16λ�仯��PWM�źš�����"������"������.

PWM0  Ϊ16λPWM.
PWM1  Ϊ14λPWM.
PWM2  Ϊ12λPWM.


******************************************/

/*************	���س�������	**************/


/*************	���ر�������	**************/

u16	pwm0,pwm1,pwm2;
bit	B_PWM0_Dir,B_PWM1_Dir,B_PWM2_Dir;	//����, 0Ϊ+, 1Ϊ-.

/*************	���غ�������	**************/



/*************  �ⲿ�����ͱ������� *****************/


void	PCA_config(void)
{
	PCA_InitTypeDef		PCA_InitStructure;

	PCA_InitStructure.PCA_Mode     = PCA_Mode_HighPulseOutput;		//PCA_Mode_PWM, PCA_Mode_Capture, PCA_Mode_SoftTimer, PCA_Mode_HighPulseOutput
	PCA_InitStructure.PCA_PWM_Wide = 0;					//PCA_PWM_8bit, PCA_PWM_7bit, PCA_PWM_6bit
	PCA_InitStructure.PCA_Interrupt_Mode = ENABLE;		//PCA_Rise_Active, PCA_Fall_Active, ENABLE, DISABLE
	PCA_InitStructure.PCA_Value    = 65535;			//����������ʱ, Ϊƥ��Ƚ�ֵ
	PCA_Init(PCA0,&PCA_InitStructure);

	PCA_InitStructure.PCA_Mode     = PCA_Mode_HighPulseOutput;		//PCA_Mode_PWM, PCA_Mode_Capture, PCA_Mode_SoftTimer, PCA_Mode_HighPulseOutput
	PCA_InitStructure.PCA_PWM_Wide = 0;					//PCA_PWM_8bit, PCA_PWM_7bit, PCA_PWM_6bit
	PCA_InitStructure.PCA_Interrupt_Mode = ENABLE;		//PCA_Rise_Active, PCA_Fall_Active, ENABLE, DISABLE
	PCA_InitStructure.PCA_Value    = 65535;				//����������ʱ, Ϊƥ��Ƚ�ֵ
	PCA_Init(PCA1,&PCA_InitStructure);

	PCA_InitStructure.PCA_Mode     = PCA_Mode_HighPulseOutput;		//PCA_Mode_PWM, PCA_Mode_Capture, PCA_Mode_SoftTimer, PCA_Mode_HighPulseOutput
	PCA_InitStructure.PCA_PWM_Wide = 0;					//PCA_PWM_8bit, PCA_PWM_7bit, PCA_PWM_6bit
	PCA_InitStructure.PCA_Interrupt_Mode = ENABLE;		//PCA_Rise_Active, PCA_Fall_Active, ENABLE, DISABLE
	PCA_InitStructure.PCA_Value    = 65535;				//����������ʱ, Ϊƥ��Ƚ�ֵ
	PCA_Init(PCA2,&PCA_InitStructure);

	PCA_InitStructure.PCA_Clock    = PCA_Clock_1T;		//PCA_Clock_1T, PCA_Clock_2T, PCA_Clock_4T, PCA_Clock_6T, PCA_Clock_8T, PCA_Clock_12T, PCA_Clock_Timer0_OF, PCA_Clock_ECI
	PCA_InitStructure.PCA_IoUse    = PCA_P24_P25_P26_P27;	//PCA_P12_P11_P10_P37, PCA_P34_P35_P36_P37, PCA_P24_P25_P26_P27
	PCA_InitStructure.PCA_Interrupt_Mode = DISABLE;		//ENABLE, DISABLE
	PCA_InitStructure.PCA_Polity   = PolityHigh;			//���ȼ�����	PolityHigh,PolityLow
	PCA_Init(PCA_Counter,&PCA_InitStructure);
}


/******************** task A **************************/
void main(void)
{
	
	PCA_config();
	CR = 0;
	pwm0 = 100;
	pwm1 = 100;
	pwm2 = 100;
	B_PWM0_Dir = 0;
	B_PWM1_Dir = 0;
	B_PWM2_Dir = 0;

	PWMn_Update(PCA0,pwm0);
	PWMn_Update(PCA1,pwm1);
	PWMn_Update(PCA2,pwm2);

	EA = 1;
	
	while (1)
	{
		delay_ms(1);

		if(B_PWM0_Dir)
		{
				if(--pwm0 <= PWM0_HIGH_MIN)		B_PWM0_Dir = 0;	//8λPWM
		}
		else	if(++pwm0 >= PWM0_HIGH_MAX)		B_PWM0_Dir = 1;	//8λPWM
		PWMn_Update(PCA0,pwm0);

		if(B_PWM1_Dir)
		{
				if(--pwm1 <= PWM1_HIGH_MIN)		B_PWM1_Dir = 0;	//7λPWM
		}
		else	if(++pwm1 >= PWM1_HIGH_MAX)		B_PWM1_Dir = 1;	//7λPWM
		PWMn_Update(PCA1,pwm1);

		if(B_PWM2_Dir)
		{
				if(--pwm2 <= PWM2_HIGH_MIN)		B_PWM2_Dir = 0;	//6λPWM
		}
		else	if(++pwm2 >= PWM2_HIGH_MAX)		B_PWM2_Dir = 1;	//6λPWM
		PWMn_Update(PCA2,pwm2);
	}
}



