#ifndef IIC_H
#define IIC_H

#include <STC15F2K60S2.h>
#include <intrins.h>

unsigned char PCF();
void Write_EEPROM(unsigned char da);
unsigned char Read_EEPROM();

#endif