#ifndef BUZZ_H
#define BUZZ_H

#include <STC15F2K60S2.h>

void Close_B();
void Oppen_B();
void Close_R();
void Oppen_R();

#endif