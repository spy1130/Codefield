unsigned char Ad_Read(unsigned char addr);
void EEPROM_Write(unsigned char* EEPROM_String,unsigned char addr,num);
void EEPROM_Read(unsigned char* EEPROM_String,unsigned char addr,num);

