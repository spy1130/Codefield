#include <STC15F2K60S2.H>

void Seg_Disp(unsigned char dula,wela,point,star,star_flag);