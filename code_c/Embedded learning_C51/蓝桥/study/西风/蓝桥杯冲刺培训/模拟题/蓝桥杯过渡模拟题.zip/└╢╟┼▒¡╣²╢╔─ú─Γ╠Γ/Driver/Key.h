#include <REGX52.H>

unsigned char Key_Read();