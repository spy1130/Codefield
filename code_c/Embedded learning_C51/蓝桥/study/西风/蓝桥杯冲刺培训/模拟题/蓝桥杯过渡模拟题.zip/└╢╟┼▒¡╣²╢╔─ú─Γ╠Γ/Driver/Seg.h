#include <REGX52.H>

void Seg_Disp(unsigned char wela,dula,point);