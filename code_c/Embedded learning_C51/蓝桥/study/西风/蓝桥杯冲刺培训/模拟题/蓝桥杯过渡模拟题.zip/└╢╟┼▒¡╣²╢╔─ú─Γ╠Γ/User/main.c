/* 头文件声明区 */
#include <REGX52.H>//单片机寄存器专用头文件
#include <Key.h>//按键底层驱动专用头文件
#include <Seg.h>//数码管底层驱动专用头文件

/* 变量声明区 */
unsigned char Key_Val,Key_Down,Key_Old,Key_Up;//按键专用变量
unsigned char Key_Slow_Down;//按键减速专用变量
unsigned char Seg_Buf[6] = {10,10,10,10,10,10};//数码管显示数据存放数组
unsigned char Seg_Pos;//数码管扫描专用变量
unsigned int Seg_Slow_Down;//数码管减速专用变量
unsigned char Seg_Disp_Mode;//数码管模式区分变量 0-温度采集界面 1-数据显示界面 2-参数设置界面
unsigned char Seg_Disp_Input[3]={11,11,11};//温度采集界面输入数组，初始值为-
unsigned char Seg_Disp_Input_Intex;//温度采集输入数组指针
unsigned char Seg_Point[6]={0,0,0,0,0,0};//小数点数据存放数组
unsigned char Seg_Point_Index=3;//小数点数组专用指针
unsigned int Timer_500Ms;//数码管闪烁专用计时变量
bit Seg_Star_Flag;//数码管闪烁标志位
unsigned char Seg_Disp_Set[2];//数据显示界面专用数组
unsigned char Seg_Disp_Par_Set[2]={30,20};//参数设置界面专用数组
bit Seg_Par_Flag;//MAX和MIN切换标志位
unsigned char Led=0xff;
unsigned char Time_Flag;//计时标志位
unsigned int Count_500Ms;//长按短按计时变量
bit Timer_Flag;
unsigned char Led_Term;//Led周期变量
unsigned char Led_Level;//等级
bit Error_Flag;








/* 键盘处理函数 */
void Key_Proc()
{
	if(Key_Slow_Down) return;
	Key_Slow_Down = 1;//键盘减速程序

	Key_Val = Key_Read();//实时读取键码值
	Key_Down = Key_Val & (Key_Old ^ Key_Val);//捕捉按键下降沿
	Key_Up = ~Key_Val & (Key_Old ^ Key_Val);
	Key_Old = Key_Val;//辅助扫描变量
	
	if(Key_Down>=1&&Key_Down<=10&&Seg_Disp_Mode==0&&Seg_Disp_Input_Intex<3)//键盘输入
	{
		Seg_Disp_Input[Seg_Disp_Input_Intex]=Key_Down-1;//输入0-9
		Seg_Disp_Input_Intex++;
	}
	
	if(Seg_Disp_Mode==2)//处于参数设置界面
	{
		if(Key_Down==14)//s14按下
			Time_Flag=1;//计时开始
	}
	if(Count_500Ms<500)//判定为短按
	{
		if(Key_Up==14)//s14抬起
		{
			Time_Flag = Count_500Ms =0;//状态复位
		}
	}
	else//长按
	{
		if(Key_Old==14)
		{
			if(Seg_Par_Flag==1)
			{
				
				if(++Seg_Disp_Par_Set[0]==70)
				 Seg_Disp_Par_Set[0]=10;
			}
			else
			{
				
				if(++Seg_Disp_Par_Set[1]==70)
				 Seg_Disp_Par_Set[1]=10;
			}
		}
		if(Key_Up==14)
			Time_Flag=Count_500Ms=0;
	}
	if(Seg_Disp_Mode==2)//处于参数设置界面
	{
		if(Key_Down==15)//s15按下
			Time_Flag=1;//计时开始
	}
	if(Count_500Ms<500)//判定为短按
	{
		
		if(Key_Up==15)//s15抬起
		{
			Time_Flag = Count_500Ms =0;//状态复位
			
		}
	}
	else//长按
	{
		if(Key_Old==15)
		{
			if(Seg_Par_Flag==1)
			{
				
				if(--Seg_Disp_Par_Set[0]==255)
				 Seg_Disp_Par_Set[0]=70;
			}
			else
			{
				if(--Seg_Disp_Par_Set[1]==255)
				 Seg_Disp_Par_Set[1]=70;
			}
		}
		if(Key_Up==15)
			Time_Flag=Count_500Ms=0;
	}
	
	
	switch(Key_Down)
	{
		case 16://切换为温度采集界面
			if(Seg_Disp_Mode!=0)
				Seg_Disp_Mode=0;
			else if(Seg_Disp_Mode==0)//如果处于温度采集界面，再次按下按键
			{
				if(Seg_Point[3]==1)//如果小数点处于前位，必定符合条件
				{
					Seg_Point[3]=0;
					Seg_Disp_Mode=1;
				}
				else
				{
					Seg_Point[4]=0;
					if((Seg_Disp_Set[0]*10+Seg_Disp_Set[1])<=85)//数据合理
					{
						Seg_Disp_Mode=1;
					}
					else//数据不合理
					{
						Seg_Disp_Input_Intex=0;//指针复位
						Seg_Disp_Input[0]=11;//清空数据，重新输入
						Seg_Disp_Input[1]=11;
						Seg_Disp_Input[2]=11;
					}
					
				}
			}
	
			
		break;
		case 11://小数点输入按键
			if(Seg_Disp_Input[2]!=11)//当数字输完之后才能输入小数点
			{
				if(Seg_Disp_Mode==0&&Seg_Point[3]==0)
				{
					if(Seg_Point[4]==0)
					{
						Seg_Point[3]=1;
					}
					else
					{
						Seg_Point[4]=0;
						Seg_Point[3]=1;
					}
				}
				
				else if(Seg_Disp_Mode==0&&Seg_Point[3]==1)
					{
						Seg_Point[3]=0;
						Seg_Point[4]=1;

					}
			}
			
			
		
		break;
		case 12://界面切换 数据显示界面与参数设置界面的切换
			if(Seg_Disp_Mode==0)//处于温度采集界面
			{
				if((Seg_Disp_Set[0]*10+Seg_Disp_Set[1])<=85)//数据合理
				{	
					Seg_Disp_Mode=1;//切换为数据显示界面
					if(Seg_Point[3]==1)//整数部分为一位
					{
						Seg_Point[3]=0;//小数点清空
						Seg_Disp_Set[0]=0;
						Seg_Disp_Set[1]=((Seg_Disp_Input[0]*100+Seg_Disp_Input[1]*10+Seg_Disp_Input[2])+55)/100%10;
		
					}
					if(Seg_Point[4]==1)//整数部分为两位
					{
						Seg_Point[4]=0;//小数点清空
						Seg_Disp_Set[0]=((Seg_Disp_Input[0]*100+Seg_Disp_Input[1]*10+Seg_Disp_Input[2])+5)/100%10;
						Seg_Disp_Set[1]=((Seg_Disp_Input[0]*100+Seg_Disp_Input[1]*10+Seg_Disp_Input[2])+5)/10%10;		

					}
					if(Seg_Point[3]!=0&&Seg_Point[4]!=0)//未输入小数点
					{
						if(Seg_Disp_Input[0]==0)
						{
							Seg_Disp_Set[0]=(Seg_Disp_Input[1]*10+Seg_Disp_Input[2])/10%10;
							Seg_Disp_Set[1]=(Seg_Disp_Input[1]*10+Seg_Disp_Input[2])%10;
						}
						else
						{
							Seg_Disp_Input_Intex=0;//指针复位
							Seg_Disp_Input[0]=11;//清空数据，重新输入
							Seg_Disp_Input[1]=11;
							Seg_Disp_Input[2]=11;
						}
					}
				
				}
				else
				{
						Seg_Disp_Input_Intex=0;//指针复位
						Seg_Point[3]=Seg_Point[4]=0;//小数点清空
						Seg_Disp_Input[0]=11;//清空数据，重新输入
						Seg_Disp_Input[1]=11;
						Seg_Disp_Input[2]=11;
				}
			}
			else if(Seg_Disp_Mode==1)//处于数据显示界面
					Seg_Disp_Mode=2;//参数设置界面
			else if(Seg_Disp_Mode==2)
			{
				if(Seg_Disp_Par_Set[0]>=Seg_Disp_Par_Set[1])//数据合理
				{
					Seg_Disp_Mode=1;
					Error_Flag=0;
				}
				else
				{
					Seg_Disp_Par_Set[0]=30;
					Seg_Disp_Par_Set[1]=20;
					Seg_Disp_Mode=1;
					Error_Flag=1;
				}
					
			}
					
			
			
		break;
		case 13://参数设置界面切换按键
			Seg_Par_Flag^=1;
		break;
		case 14://温度参数加
			if(Seg_Disp_Mode==2)
			{
				if(Seg_Par_Flag==1)
				{
					
					if(++Seg_Disp_Par_Set[0]>70)//温度参数范围10~70
						Seg_Disp_Par_Set[0]=10;
				}
				
				else
				{
					
					if(++Seg_Disp_Par_Set[1]>70)//温度参数范围10~70
						Seg_Disp_Par_Set[1]=10;
				}
			}
		break;
		case 15://温度参数减
			if(Seg_Disp_Mode==2)
			{
				if(Seg_Par_Flag==1)
				{
					
					if(--Seg_Disp_Par_Set[0]==255)//温度参数范围10~70
						Seg_Disp_Par_Set[0]=70;
				}
				else
				{
					
					if(--Seg_Disp_Par_Set[1]==255)//温度参数范围10~70
						Seg_Disp_Par_Set[1]=70;
				}
			}
		break;
	
		
	}

}


/* 信息处理函数 */
void Seg_Proc()
{
	if(Seg_Slow_Down) return;
	Seg_Slow_Down = 1;//数码管减速程序
	
	switch(Seg_Disp_Mode)
	{
		case 0://温度采集界面
			Seg_Buf[0]=12;
			Seg_Buf[1]=10;
		  Seg_Buf[2]=10;
			Seg_Buf[3]=Seg_Disp_Input[0];
			Seg_Buf[4]=Seg_Disp_Input[1];
			Seg_Buf[5]=Seg_Disp_Input[2];
			Seg_Buf[Seg_Disp_Input_Intex+3]=Seg_Star_Flag?Seg_Disp_Input[Seg_Disp_Input_Intex]:10;

		break;
		case 1://数据显示界面
			Seg_Buf[0]=13;
			Seg_Buf[1]=10;
		  Seg_Buf[2]=10;
			Seg_Buf[3]=10;
			Seg_Buf[4]=Seg_Disp_Set[0];
			Seg_Buf[5]=Seg_Disp_Set[1];
		
		break;
		case 2://参数设置界面
			Seg_Buf[0]=14;
			Seg_Buf[1]=10;
		  Seg_Buf[2]=Seg_Disp_Par_Set[0]/10%10;
			Seg_Buf[3]=Seg_Disp_Par_Set[0]%10;
			Seg_Buf[4]=Seg_Disp_Par_Set[1]/10%10;
			Seg_Buf[5]=Seg_Disp_Par_Set[1]%10;
			if(Seg_Par_Flag==1)//MAX闪烁
			{
				Seg_Buf[2]=Seg_Star_Flag?Seg_Disp_Par_Set[0]/10%10:10;
				Seg_Buf[3]=Seg_Star_Flag?Seg_Disp_Par_Set[0]%10:10;
			}
			else//MIN闪烁
			{
				Seg_Buf[4]=Seg_Star_Flag?Seg_Disp_Par_Set[1]/10%10:10;
				Seg_Buf[5]=Seg_Star_Flag?Seg_Disp_Par_Set[1]%10:10;
			}
		
		break;
		
		
	}

}

/* 其他显示函数 */
void Led_Proc()
{
	if(Led_Term<Led_Level)
		P1=Led;
	else
		P1=0xff;
	
	if(Seg_Disp_Mode==1)
	{
		if((Seg_Disp_Set[0]*10+Seg_Disp_Set[1])>Seg_Disp_Par_Set[0])//当前温度大于MAX
		{
			Led&=0xfe;//L1亮
			Led_Level=2;
		}
		else
			Led|=~0xfe;
		
		if((Seg_Disp_Set[0]*10+Seg_Disp_Set[1])>=Seg_Disp_Par_Set[1]&&(Seg_Disp_Set[0]*10+Seg_Disp_Set[1])<=Seg_Disp_Par_Set[0])//当前温度大于MIN小于MAX
		{
			Led&=0xfd;//L2亮
			Led_Level=6;
		}
		else
			Led|=~0xfd;
		
		if((Seg_Disp_Set[0]*10+Seg_Disp_Set[1])<Seg_Disp_Par_Set[1])//当前温度小于MIN
		{
			Led&=0xfb;//L3亮
			Led_Level=12;
		}
		else
			Led|=~0xfb;
	}
	if(Error_Flag==1)//数据输入有误
	{
		Led&=0xf7;//L4亮
	}
	else
		Led|=~0xf7;
	


	
		
	
}

/* 定时器0中断初始化函数 */
void Timer0Init(void)		//1毫秒@12.000MHz
{
	TMOD &= 0xF0;		//设置定时器模式
	TMOD |= 0x01;		//设置定时器模式
	TL0 = 0x18;		//设置定时初始值
	TH0 = 0xFC;		//设置定时初始值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
	ET0 = 1;        //定时器0中断打开
	EA = 1;         //总中断打开
}

/* 定时器0中断服务函数 */
void Timer0Server() interrupt 1
{
 	TL0 = 0x18;		//设置定时初始值
	TH0 = 0xFC;		//设置定时初始值   
	if(++Key_Slow_Down == 10) Key_Slow_Down = 0;//键盘减速专用
	if(++Seg_Slow_Down == 500) Seg_Slow_Down = 0;//数码管减速专用
	if(++Seg_Pos == 6) Seg_Pos = 0;//数码管显示专用
	Seg_Disp(Seg_Pos,Seg_Buf[Seg_Pos],Seg_Point[Seg_Pos]);
	
	if(++Timer_500Ms==500)//数码管闪烁计时
	{
		Timer_500Ms=0;
		Seg_Star_Flag^=1;
		
	}
	if(Time_Flag==1)//Key_Down按下开始计时标志位
	{
		if(++Count_500Ms==600)//长按短按计时变量
		{
			Count_500Ms=600;//使该变量卡在600
			
		}
	}
	
	if(++Led_Term==12)Led_Term=0;//以十二为周期
	
}

/* Main */
void main()
{
	Timer0Init();
	while (1)
	{
		Key_Proc();
		Seg_Proc();
		Led_Proc();
	}
}