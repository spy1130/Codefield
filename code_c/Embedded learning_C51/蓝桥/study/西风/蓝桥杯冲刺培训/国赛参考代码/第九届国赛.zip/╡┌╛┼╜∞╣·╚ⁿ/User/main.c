/* 头文件声明区 */
#include <STC15F2K60S2.H>//单片机寄存器专用头文件
#include <Init.h>//初始化底层驱动专用头文件
#include <Led.h>//Led底层驱动专用头文件
#include <Key.h>//按键底层驱动专用头文件
#include <Seg.h>//数码管底层驱动专用头文件
#include "iic.h"//单总线底层驱动专用头文件
#include "onewire.h"//温度底层驱动专用头文件

/* 变量声明区 */
unsigned char Key_Val,Key_Down,Key_Old,Key_Up;//按键专用变量
unsigned char Key_Slow_Down;//按键减速专用变量
unsigned char Seg_Buf[8] = {10,10,10,10,10,10,10,10};//数码管显示数据存放数组
unsigned char Seg_Point[8] = {0,0,0,0,0,0,0,0};//数码管小数点数据存放数组
unsigned char Seg_Pos;//数码管扫描专用变量
unsigned int Seg_Slow_Down;//数码管减速专用变量
unsigned char ucLed[8] = {0,0,0,0,0,0,0,0};//Led显示数据存放数组
unsigned char Seg_Disp_Mode;//数码管显示模式专用变量 0-电压显示 1-频率显示 2-温度显示 3-数据回显 4-阈值设置
unsigned int Timer_1000Ms;//1000毫秒计时变量
unsigned int Freq;//实时频率变量
unsigned int Data_Echo[3];//回显数据储存数组 0-电压 1-频率 2-温度
unsigned char Data_Echo_Index;//数据回显数组指针
unsigned char EEPROM_Dat[5];//EEPROM数据读写储存数组
unsigned char Voltage_Val_Disp = 10;//电压阈值显示值 默认值 1.0V
unsigned char Voltage_Val_Ctrol = 10;//电压阈值控制值 默认值 1.0V
unsigned int Timer_800Ms;//800毫秒计时变量
unsigned char Timer_200Ms;//200毫秒计时变量
float Temperature;//实时温度变量
float Voltage;//实时电压变量
bit Key_Flag;//按键标志位
bit Led_Star_Flag;//Led闪烁标志位

/* 键盘处理函数 */
void Key_Proc()
{
	if(Key_Slow_Down) return;
	Key_Slow_Down = 1;//键盘减速程序

	Key_Val = Key_Read();//实时读取键码值
	Key_Down = Key_Val & (Key_Old ^ Key_Val);//捕捉按键下降沿
	Key_Up = ~Key_Val & (Key_Old ^ Key_Val);//捕捉按键上降沿
	Key_Old = Key_Val;//辅助扫描变量

	switch(Key_Down)
	{
		case 4://切换按键
			if(Seg_Disp_Mode != 3)
			{
				if(++Seg_Disp_Mode == 3) //切换数据显示
					Seg_Disp_Mode = 0;
			}
			else
			{
				if(++Data_Echo_Index == 3) //切换回显显示
					Data_Echo_Index = 0;				
			}
		break;
		case 5://储存按键
			EEPROM_Dat[0] = Voltage * 10;//储存电压值
			EEPROM_Dat[1] = Freq / 256;//储存频率值高八位
			EEPROM_Dat[2] = Freq % 256;//储存频率值低八位
			EEPROM_Dat[3] = (unsigned int)(Temperature * 100) / 256;//储存温度值高八位
			EEPROM_Dat[4] = (unsigned int)(Temperature * 100) % 256;//储存温度值低八位
			EEPROM_Write(EEPROM_Dat,0,5);////将数据写入EEPROM中
		break;
		case 6://回显按键
			if(Seg_Disp_Mode != 4) //处于非阈值设置界面
			{
				EEPROM_Read(EEPROM_Dat,0,5);//读取EEPROM储存数据
				Data_Echo[0] = EEPROM_Dat[0];//读取电压值
				Data_Echo[1] = EEPROM_Dat[1] << 8 | EEPROM_Dat[2];//读取频率值
				Data_Echo[2] = EEPROM_Dat[3] << 8 | EEPROM_Dat[4];//读取温度值
				Seg_Disp_Mode = 3;//切换到回显界面
			}
		break;
		case 7://设置按键
			if(Seg_Disp_Mode != 4) //处于非阈值设置界面
				Seg_Disp_Mode = 4;
			else
			{
				Seg_Disp_Mode = 0;//切换回数据显示界面
				Voltage_Val_Ctrol = Voltage_Val_Disp;//保存当前阈值参数
				EEPROM_Write(&Voltage_Val_Ctrol,8,1);////将数据写入EEPROM中
			}
		break;
	}
	
	if(Seg_Disp_Mode == 4) //处于阈值设置界面
	{
		if(Key_Down == 6) //检测到按键按下
			Key_Flag = 1; //标志位拉高 开始计时
		if(Timer_800Ms < 800) //在0.8S之内
		{
			if(Key_Up == 6) //检测到按键松手
			{
				if(++Voltage_Val_Disp == 51) //设置参数上限
					Voltage_Val_Disp = 1;
				Key_Flag = Timer_800Ms = 0;//复位判断变量
			}
		}
		else //在0.8S之外
		{
			if(Key_Old == 6) //S6一直按下
			{
				if(++Voltage_Val_Disp == 51) //设置参数上限
					Voltage_Val_Disp = 1;				
			}
			if(Key_Up == 6) //检测到按键松手
				Key_Flag = Timer_800Ms = 0;//复位判断变量
		}
	}
}

/* 信息处理函数 */
void Seg_Proc()
{
	unsigned char i = 3;//循环专用变量
	
	/* 
		减速的实际意义是避免程序循环执行过快导致的芯片数据读取出错
		在题目中出现多个芯片时 可设计不同的减速执行周期 达到轮询读取的效果
		避免单片机在某一时刻读取多个芯片所导致的效率较慢或数据错误的问题
	*/
	
	switch(Seg_Slow_Down)
	{
		case 200:
			Seg_Slow_Down += 1;//保证这一毫秒内只读取一次 避免重复读取数据错误
			Voltage = Ad_Read(0x03) / 51.0;//读取电压值
		break;
		case 400:
			Seg_Slow_Down += 1;//保证这一毫秒内只读取一次 避免重复读取数据错误
			Temperature = rd_temperature();//读取温度值
		break;
	}		
	
	if(!(Seg_Slow_Down % 30)) //数码管每30Ms刷新一次 若不加限制 高位熄灭覆盖太快会导致闪烁
	{
		Seg_Slow_Down += 1;//保证这一毫秒内只读取一次 避免重复读取数据错误
		Seg_Buf[0] = 11 + Seg_Disp_Mode;//界面标识符
		switch(Seg_Disp_Mode)
		{
			case 0://电压显示界面
				Seg_Buf[4] = Seg_Buf[5] = 10;
				Seg_Buf[6] = (unsigned char)Voltage;
				Seg_Buf[7] = (unsigned int)(Voltage * 10) % 10;
				Seg_Point[5] = 0;//熄灭第五位小数点
				Seg_Point[6] = 1;//使能第六位小数点
			break;
			case 1://频率显示界面
				Seg_Buf[3] = Freq / 10000 % 10;
				Seg_Buf[4] = Freq / 1000 % 10;
				Seg_Buf[5] = Freq / 100 % 10;
				Seg_Buf[6] = Freq / 10 % 10;
				Seg_Buf[7] = Freq % 10;
				Seg_Point[6] = 0;//熄灭第六位小数点
				while(Seg_Buf[i] == 0)//熄灭高位未启用数码管
				{
					Seg_Buf[i] = 10;
					if(++i == 7) break;
				}
			break;
			case 2://温度显示界面
				Seg_Buf[3] = 10;
				Seg_Buf[4] = (unsigned char)Temperature / 10 % 10;
				Seg_Buf[5] = (unsigned char)Temperature % 10;
				Seg_Buf[6] = (unsigned int)(Temperature * 100) / 10 % 10;
				Seg_Buf[7] = (unsigned int)(Temperature * 100) % 10;	
				Seg_Point[5] = 1;//使能第五位小数点
			break;
			case 3://数据回显界面
				Seg_Buf[1] = 11 + Data_Echo_Index;//界面标识符
				Seg_Buf[3] = Data_Echo[Data_Echo_Index] / 10000 % 10;
				Seg_Buf[4] = Data_Echo[Data_Echo_Index] / 1000 % 10;
				Seg_Buf[5] = Data_Echo[Data_Echo_Index] / 100 % 10;
				Seg_Buf[6] = Data_Echo[Data_Echo_Index] / 10 % 10;
				Seg_Buf[7] = Data_Echo[Data_Echo_Index] % 10;
				Seg_Point[5] = (Data_Echo_Index == 2);//温度回显点亮第六位小数点
				Seg_Point[6] = (Data_Echo_Index == 0);//电压回显点亮第六位小数点
				while(Seg_Buf[i] == 0)//熄灭高位未启用数码管
				{
					Seg_Buf[i] = 10;
					if(++i == (7 - (!Data_Echo_Index))) break; //避免电压界面0.X时整数部分熄灭
				}					
			break;
			case 4://阈值设置界面
				for(i=1;i<6;i++)
					Seg_Buf[i] = 10;
				Seg_Point[5] = 0;
				Seg_Point[6] = 1;
				Seg_Buf[6] = Voltage_Val_Disp / 10 % 10;
				Seg_Buf[7] = Voltage_Val_Disp % 10;
			break;
		}
	}

}

/* 其他显示函数 */
void Led_Proc()
{
	unsigned char i;//循环专用变量
	for(i=0;i<3;i++)
		ucLed[2-i] = (i == Seg_Disp_Mode);
	ucLed[7] = (Voltage > (Voltage_Val_Ctrol / 10.0)) & Led_Star_Flag;
}

/* 定时器0初始化函数 */
void Timer0Init(void)		//0毫秒@12.000MHz
{
	AUXR &= 0x7F;		//定时器时钟12T模式
	TMOD &= 0xF0;		//设置定时器模式
	TMOD |= 0x04;		//设置计数模式
	TL0 = 0x00;		//设置定时初值
	TH0 = 0x00;		//设置定时初值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
}

/* 定时器2初始化函数 */
void Timer2Init(void)		//1毫秒@12.000MHz
{
	AUXR &= 0xFB;		//定时器时钟12T模式
	T2L = 0x18;		//设置定时初值
	T2H = 0xFC;		//设置定时初值
	AUXR |= 0x10;		//定时器2开始计时
	IE2  |=  0x04;    //允许定时器2中断
	EA = 1;					//总中断打开
}



/* 定时器2中断服务函数 */
void Timer2Server() interrupt 12
{  
	if(++Key_Slow_Down == 10) Key_Slow_Down = 0;//键盘减速专用
	if(++Seg_Slow_Down == 500) Seg_Slow_Down = 0;//数码管减速专用
	if(++Seg_Pos == 8) Seg_Pos = 0;//数码管显示专用
	Seg_Disp(Seg_Pos,Seg_Buf[Seg_Pos],Seg_Point[Seg_Pos]);
	Led_Disp(Seg_Pos,ucLed[Seg_Pos]);
	
	if(++Timer_1000Ms == 1000) //实时更新频率值
	{
		Timer_1000Ms = 0;
		TR0 = 0;
		Freq = TH0 << 8 | TL0;
		TH0 = TL0 = 0;
		TR0 = 1;
	}
	
	if(Key_Flag == 1) //检测到按键按下
	{
		if(++Timer_800Ms > 800) //大于0.8秒后卡住 防止一直自加导致溢出
			Timer_800Ms = 900;
	}
	
	if(++Timer_200Ms == 200)
	{
		Timer_200Ms = 0;
		Led_Star_Flag ^= 1;
	}
}

/* Main */
void main()
{
	System_Init();
	Ad_Read(0x03);//上电读取电压值 避免错误数据 2.5V
	EEPROM_Read(&Voltage_Val_Ctrol,8,1);//上电读取设置阈值参数
	Voltage_Val_Disp = Voltage_Val_Ctrol;
	Timer2Init();
	Timer0Init();
	while (1)
	{
		Key_Proc();
		Seg_Proc();
		Led_Proc();
	}
}