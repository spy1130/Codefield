/* 头文件声明区 */
#include <STC15F2K60S2.H>//单片机寄存器专用头文件
#include <Init.h>//初始化底层驱动专用头文件
#include <Led.h>//Led底层驱动专用头文件
#include <Key.h>//按键底层驱动专用头文件
#include <Seg.h>//数码管底层驱动专用头文件
#include <Uart.h>//串口底层驱动专用头文件
#include "onewire.h"//温度底层驱动专用头文件
#include <ultrasound.h>//超声波底层驱动专用头文件
#include "iic.h"//单总线底层驱动专用头文件
#include <stdio.h>//标准库底层驱动专用头文件

/* 变量声明区 */
unsigned char Key_Val,Key_Down,Key_Old,Key_Up;//按键专用变量
unsigned char Key_Slow_Down;//按键减速专用变量
unsigned char Seg_Buf[8] = {10,10,10,10,10,10,10,10};//数码管显示数据存放数组
unsigned char Seg_Point[8] = {0,0,0,0,0,0,0,0};//数码管小数点数据存放数组
unsigned char Seg_Pos;//数码管扫描专用变量
unsigned int Seg_Slow_Down;//数码管减速专用变量
unsigned char ucLed[8] = {0,0,0,0,0,0,0,0};//Led显示数据存放数组
unsigned int Uart_Slow_Down;//串口减速专用变量
unsigned char Uart_Recv[10];//串口接收数据储存数组 默认10个字节 若接收数据较长 可更改最大字节数
unsigned char Uart_Recv_Index;//串口接收数组指针
unsigned char Seg_Disp_Mode;//数码管显示模式变量 0-温度显示 1-距离显示 2-次数显示 3-参数界面
unsigned char Wave;//实时距离显示变量
unsigned char Change_Num;//变更次数储存变量
float Temperature;//实时温度显示变量
unsigned char Parm_Disp[2] = {30,35};//参数数据显示数组
unsigned char Parm_Ctrol[2] = {30,35};//参数数据设置数组
unsigned int Timer_1000Ms;//一千毫秒计时变量
bit Key_Flag;//按键计时标志位
bit Parm_Index;//参数数组指针
bit Output_Flag = 1;//输出模式标志位 0-停止状态 1-启动状态
bit Uart_Flag;//溢出标志位

/* 键盘处理函数 */
void Key_Proc()
{
	if(Key_Slow_Down) return;
	Key_Slow_Down = 1;//键盘减速程序

	Key_Val = Key_Read();//实时读取键码值
	Key_Down = Key_Val & (Key_Old ^ Key_Val);//捕捉按键下降沿
	Key_Up = ~Key_Val & (Key_Old ^ Key_Val);//捕捉按键上降沿
	Key_Old = Key_Val;//辅助扫描变量

	if(Key_Down == 12 || Key_Down == 13)
		Key_Flag = 1;
	
	if(Timer_1000Ms < 1000 && Key_Flag == 1) //短按
	{
		switch(Key_Up)
		{
			case 12://切换功能按键
				Timer_1000Ms = Key_Flag = 0;//判断标志位复位
				if(Seg_Disp_Mode < 3) //处于数据显示界面
				{
					if(++Seg_Disp_Mode == 3)
						Seg_Disp_Mode = 0;
				}
				else//处于参数设置界面
					Parm_Index ^= 1;
			break;
			case 13:
				Timer_1000Ms = Key_Flag = 0;//判断标志位复位
				if(Seg_Disp_Mode < 3) //处于数据显示界面
					Seg_Disp_Mode = 3;//切换到参数设置界面
				else//处于参数设置界面
				{
					Parm_Index = 0;//指针复位
					Seg_Disp_Mode = 0;//切换到温度显示界面
					if(Parm_Ctrol[0] != Parm_Disp[0] || Parm_Ctrol[1] != Parm_Disp[1]) //有变更参数
					{
						Change_Num++;//更新变更次数
						EEPROM_Write(&Change_Num,0,1);
						Parm_Ctrol[0] = Parm_Disp[0];
						Parm_Ctrol[1] = Parm_Disp[1];
					}
				}				
			break;
		}
	}
	else //长按
	{
		switch(Key_Old)
		{
			case 12://复位按键
				Timer_1000Ms = Key_Flag = 0;//判断标志位复位
				Change_Num = 0;//清空计数值
				EEPROM_Write(&Change_Num,0,1);
			break;
			case 13://输出按键
				Output_Flag ^= 1;//切换输出模式
			break;
		}
	}
	
	switch(Key_Down)
	{
		case 16://参数自减按键
			if(Seg_Disp_Mode == 3) //处于参数设置界面
			{
				Parm_Disp[Parm_Index] -= 2+(Parm_Index * 3);
				if(Parm_Disp[Parm_Index] > 200) Parm_Disp[Parm_Index] = 0;
			}
		break;
		case 17://参数自加按键
			if(Seg_Disp_Mode == 3) //处于参数设置界面
			{
				Parm_Disp[Parm_Index] += 2+(Parm_Index * 3);
				if(Parm_Disp[Parm_Index] > 99) Parm_Disp[Parm_Index] = 99;
			}
		break;
	}
}

/* 信息处理函数 */
void Seg_Proc()
{
	unsigned char i = 3;//循环专用变量
//	if(Seg_Slow_Down) return;
//	Seg_Slow_Down = 1;//数码管减速程序
	
	switch(Seg_Slow_Down) //轮询读取数据
	{
		case 200://距离读取
			Seg_Slow_Down += 1;
			Wave = Ut_Wave_Data();
			if(Wave > 99) Wave = 99;//限制超声波读取距离
		break;
		case 300://温度读取
			Seg_Slow_Down += 1;
			Temperature = rd_temperature();
		break;
	}

	if(!(Seg_Slow_Down % 30)) //限制数码管扫描周期 避免影响高位熄灭功能
	{
		Seg_Slow_Down += 1;
		Seg_Buf[0] = Seg_Disp_Mode + 11;//模式提示符
		switch(Seg_Disp_Mode)
		{
			case 0://温度显示
				Seg_Point[5] = 1;//使能第六位小数点
				Seg_Buf[3] = 10;
				Seg_Buf[4] = (unsigned char)Temperature / 10 % 10;
				Seg_Buf[5] = (unsigned char)Temperature % 10;
				Seg_Buf[6] = (unsigned int)(Temperature * 100) / 10 % 10;		
				Seg_Buf[7] = (unsigned int)(Temperature * 100) % 10;
			break;
			case 1://距离显示
				Seg_Point[5] = 0;//关闭第六位小数点
				Seg_Buf[4] = Seg_Buf[5] = 10;
				Seg_Buf[6] = Wave / 10 % 10;
				Seg_Buf[7] = Wave % 10;
			break;
			case 2://变更次数
				Seg_Buf[3] = Change_Num / 10000 % 10;
				Seg_Buf[4] = Change_Num / 1000 % 10;
				Seg_Buf[5] = Change_Num / 100 % 10;
				Seg_Buf[6] = Change_Num / 10 % 10;
				Seg_Buf[7] = Change_Num % 10;
				while(Seg_Buf[i] == 0)
				{
					Seg_Buf[i] = 10;
					if(++i == 7) break;
				}
			break;
			case 3://参数设置
				Seg_Point[5] = 0;//关闭第六位小数点
				Seg_Buf[3] = (unsigned char)Parm_Index + 1;
				Seg_Buf[4] = Seg_Buf[5] = 10;
				Seg_Buf[6] = Parm_Disp[Parm_Index] / 10;
				Seg_Buf[7] = Parm_Disp[Parm_Index] % 10;
			break;
		}
	}
}

/* 其他显示函数 */
void Led_Proc()
{
	/* DAC输出 */
	if(Output_Flag == 0) //停止状态
		Da_Write(0.4*51);
	else //开始状态
		Da_Write((Wave>Parm_Ctrol[1]?4:2)*51);
	
	/* Led显示 */
	ucLed[0] = Temperature>Parm_Ctrol[0];
	ucLed[1] = Wave<Parm_Ctrol[1];
	ucLed[2] = Output_Flag;
}

/* 串口处理函数 */
void Uart_Proc()
{
	if(Uart_Slow_Down) return;
	Uart_Slow_Down = 1;//串口减速程序	
	
	if(Uart_Recv_Index > 0) //接收到数据
	{
		if(Uart_Recv_Index == 4 || Uart_Recv_Index == 6) //有效指令长度
		{
			if(Uart_Recv[0] == 'S' && Uart_Recv[1] == 'T' && Uart_Recv[2] == '\r' && Uart_Recv[3] == '\n') //查询数据指令
				printf("$%d,%.2f\r\n",(unsigned int)Wave,Temperature);
			else if(Uart_Recv[0] == 'P' && Uart_Recv[1] == 'A' && Uart_Recv[2] == 'R' && Uart_Recv[3] == 'A' && Uart_Recv[4] == '\r' && Uart_Recv[5] == '\n') //查询参数指令
				printf("#%d,%d\r\n",(unsigned int)Parm_Ctrol[0],(unsigned int)Parm_Ctrol[1]);
			else printf("ERROR\r\n");
		}
		else 
			printf("ERROR\r\n");
		Uart_Flag = Uart_Recv_Index = 0;//指针复位
	}
	
	if(Uart_Flag == 1)
	{
		Uart_Flag = 0;
		printf("ERROR\r\n");
	}
}

/* 定时器0中断初始化函数 */
void Timer0Init(void)		//1毫秒@12.000MHz
{
	AUXR &= 0x7F;		//定时器时钟12T模式
	TMOD &= 0xF0;		//设置定时器模式
	TL0 = 0x18;		//设置定时初始值
	TH0 = 0xFC;		//设置定时初始值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
	ET0 = 1;    //定时器中断0打开
	EA = 1;     //总中断打开
}

/* 定时器0中断服务函数 */
void Timer0Server() interrupt 1
{  
	if(++Key_Slow_Down == 10) Key_Slow_Down = 0;//键盘减速专用
	if(++Seg_Slow_Down == 500) Seg_Slow_Down = 0;//数码管减速专用
	if(++Uart_Slow_Down == 200) Uart_Slow_Down = 0;//串口减速专用
	if(++Seg_Pos == 8) Seg_Pos = 0;//数码管显示专用
	Seg_Disp(Seg_Pos,Seg_Buf[Seg_Pos],Seg_Point[Seg_Pos]);
	Led_Disp(Seg_Pos,ucLed[Seg_Pos]);
	
	if(Key_Flag == 1) Timer_1000Ms++;//按键按下
}

/* 串口1中断服务函数 */
void Uart1Server() interrupt 4
{
	if(RI == 1 && Uart_Recv_Index < 8) //串口接收数据
	{
		Uart_Recv[Uart_Recv_Index] = SBUF;
		Uart_Recv_Index++;
		RI = 0;
	}
	
	if(Uart_Recv_Index > 6) 
	{
		Uart_Recv_Index = 0;
		Uart_Flag = 1;
	}
}

/* Main */
void main()
{
	System_Init();
	while(rd_temperature() == 85);//避免上电读取85.00
	Temperature = rd_temperature();//避免上电显示00.00
	EEPROM_Read(&Change_Num,0,1);
	Timer0Init();
	UartInit();
	while (1)
	{
		Key_Proc();
		Seg_Proc();
		Led_Proc();
		Uart_Proc();
	}
}