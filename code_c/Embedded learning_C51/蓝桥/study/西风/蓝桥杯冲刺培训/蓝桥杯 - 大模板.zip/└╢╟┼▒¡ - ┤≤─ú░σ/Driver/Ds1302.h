void Write_Ds1302(unsigned char temp);
void Write_Ds1302_Byte( unsigned char address,unsigned char dat );
unsigned char Read_Ds1302_Byte( unsigned char address );
void Read_Rtc(unsigned char* ucRtc);
void Set_Rtc(unsigned char* ucRtc);
