#include <STC15F2K60S2.H>


void Timer0Init(void);
void Timer1Init(void);