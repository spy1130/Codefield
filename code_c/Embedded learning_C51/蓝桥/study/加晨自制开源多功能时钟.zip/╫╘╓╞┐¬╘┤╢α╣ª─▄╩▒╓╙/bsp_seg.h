#include <STC15F2K60S2.H>



void Seg_Tran(unsigned char*Seg_String,unsigned char*Seg_Buf);
void Seg_Disp(unsigned char*Seg_Buf,unsigned char pos);