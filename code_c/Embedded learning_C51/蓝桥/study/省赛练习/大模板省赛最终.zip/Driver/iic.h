unsigned char Ad_Read(unsigned char addr);
void Pcf8591_Dac(unsigned char trans_dat);
void EEPROM_Write(unsigned char* EEPROM_String, unsigned char addr, unsigned char num);
void EEPROM_Read(unsigned char* EEPROM_String, unsigned char addr, unsigned char num);
