void Set_Rtc(unsigned char* ucRTC);
void Read_Rtc(unsigned char* ucRTC);