#include <STC15F2K60S2.H>
void Led_Disp(unsigned char addr,enable);
void Beep(unsigned char enable);
void Relay(unsigned char enable);
