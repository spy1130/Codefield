#ifndef _TIME_H_
#define _TIME_H_

#include "SysConfig.h"

void DrvTimerFcInit(void);

#endif
