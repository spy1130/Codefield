#ifndef _DRV_ADC_H_
#define _DRV_ADC_H_
#include "SysConfig.h"

void DrvAdcInit(void);
float Drv_AdcGetBatVot(void);

#endif
