#include "Drv_Gpio.h"

void DrvGpioSenserCsPinInit(void)
{

}

void DrvGpioCsPinCtrlAk8975(u8 ena)
{

}

void DrvGpioCsPinCtrlSpl06(u8 ena)
{

}

void DrvGpioCsPinCtrlBmi088Acc(u8 ena)
{

}
void DrvGpioCsPinCtrlBmi088Gyr(u8 ena)
{

}

