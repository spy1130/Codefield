#ifndef DRV_ADC_H
#define DRV_ADC_H
#include "sysconfig.h"

void DrvAdcInit(void); 
float Drv_AdcGetBatVot(void);

#endif

