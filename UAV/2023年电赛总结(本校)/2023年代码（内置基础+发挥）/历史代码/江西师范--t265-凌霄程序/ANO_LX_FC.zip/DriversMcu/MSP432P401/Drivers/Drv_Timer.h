#ifndef __DRVTIMER_H
#define __DRVTIMER_H
//==����
#include "SysConfig.h"

void DrvTimerFcInit(void);

#endif
