#ifndef _DRV_PARAMTER_H_
#define _DRV_PARAMTER_H_

#include "sysconfig.h"

void DvrParamterInit(void);
void DvrParamterRead(void);
void DvrParamterSave(void);

#endif

