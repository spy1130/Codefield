#ifndef _DRV_RCIN_H_
#define _DRV_RCIN_H_
#include "sysconfig.h"

void DrvRcPpmInit(void);
void DrvRcSbusInit(void);

#endif
