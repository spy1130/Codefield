#include "Drv_Paramter.h"

void DvrParamterInit(void)
{

}

void DvrParamterRead(void)
{

}

void DvrParamterSave(void)
{

}
